#ifndef E2TOOLS_LS_H
#define E2TOOLS_LS_H

extern long do_list_dir(int argc, char *argv[]);

#endif /* !E2TOOLS_LS_H */
