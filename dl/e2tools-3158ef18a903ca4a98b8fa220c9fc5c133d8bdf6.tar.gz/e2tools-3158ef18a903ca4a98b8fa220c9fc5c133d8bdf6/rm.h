#ifndef E2TOOLS_RM_H
#define E2TOOLS_RM_H

extern long e2rm(int argc, char *argv[]);

#endif /* !E2TOOLS_RM_H */
